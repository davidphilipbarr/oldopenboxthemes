#!/bin/sh

# normal folder 
rm gnome-fs-directory.png
rm gtk-directory.png
rm stock_folder.png
rm inode-directory.png

# network folder
rm gnome-fs-share.png                     
rm gnome-fs-smb.png                      
rm gnome-fs-ssh.png                     
rm gnome-fs-ftp.png                       
rm gnome-fs-nfs.png                       
rm network.png

#start here 
rm distributor-logo.png                   
rm novell-button.png                 
rm gnome-main-menu.png                                       

# saved search              
rm application-x-gnome-saved-search.png   

               

# home 
rm gnome-fs-home.png                      
rm folder_home.png                        
                     
##

# network server 
#ln -s -f network-server.png gnome-mime-x-directory-nfs-server.png  
#ln -s -f network-server.png gnome-mime-x-directory-smb-server.png  
#ln -s -f network-server.png gnome-mime-x-directory-smb-share.png
#ln -s -f network-server.png gnome-mime-x-directory-smb-workgroup.png
#ln -s -f network-server.png gnome-fs-server.png                    
#ln -s -f network-server.png redhat-network-server.png
#ln -s -f network-server.png server.png

# net work group
#ln -s -f network-workgroup.png gnome-fs-network.png
#ln -s -f network-workgroup.png gtk-network.png            
#ln -s -f network-workgroup.png network_local.png


#user-bookmarks.png

# trash 
#ln -s -f user-trash.png trashcan_empty.png
#ln -s -f user-trash.png xfce-trash_empty.png
#ln -s -f user-trash.png emptytrash.png                         
#ln -s -f user-trash.png gnome-stock-trash.png

# desktop
#ln -s -f user-desktop.png desktop.png                            
#ln -s -f user-desktop.png gnome-fs-desktop.png    
