#!/bin/sh

# normal folder 
ln -s -f folder.png gnome-fs-directory.png
ln -s -f folder.png gtk-directory.png
ln -s -f folder.png stock_folder.png
ln -s -f folder.png inode-directory.png

# network folder
ln -s -f folder-remote.png gnome-fs-share.png                     
ln -s -f folder-remote.png gnome-fs-smb.png                      
ln -s -f folder-remote.png gnome-fs-ssh.png                     
ln -s -f folder-remote.png gnome-fs-ftp.png                       
ln -s -f folder-remote.png gnome-fs-nfs.png                       
ln -s -f folder-remote.png network.png

#start here 
ln -s -f start-here.png distributor-logo.png                   
ln -s -f start-here.png novell-button.png                 
ln -s -f start-here.png gnome-main-menu.png                                       

# saved search              
ln -s -f folder-saved-search.png application-x-gnome-saved-search.png   

               

# home 
ln -s -f user-home.png gnome-fs-home.png                      
ln -s -f user-home.png folder_home.png                        
                     
##

# network server 
#ln -s -f network-server.png gnome-mime-x-directory-nfs-server.png  
#ln -s -f network-server.png gnome-mime-x-directory-smb-server.png  
#ln -s -f network-server.png gnome-mime-x-directory-smb-share.png
#ln -s -f network-server.png gnome-mime-x-directory-smb-workgroup.png
#ln -s -f network-server.png gnome-fs-server.png                    
#ln -s -f network-server.png redhat-network-server.png
#ln -s -f network-server.png server.png

# net work group
#ln -s -f network-workgroup.png gnome-fs-network.png
#ln -s -f network-workgroup.png gtk-network.png            
#ln -s -f network-workgroup.png network_local.png


#user-bookmarks.png

# trash 
#ln -s -f user-trash.png trashcan_empty.png
#ln -s -f user-trash.png xfce-trash_empty.png
#ln -s -f user-trash.png emptytrash.png                         
#ln -s -f user-trash.png gnome-stock-trash.png

# desktop
#ln -s -f user-desktop.png desktop.png                            
#ln -s -f user-desktop.png gnome-fs-desktop.png    



###############################################


