#!/bin/sh

# normal folder 
rm gnome-fs-directory.svg
rm gtk-directory.svg
rm stock_folder.svg
rm inode-directory.svg

# network folder
rm gnome-fs-share.svg                     
rm gnome-fs-smb.svg                      
rm gnome-fs-ssh.svg                     
rm gnome-fs-ftp.svg                       
rm gnome-fs-nfs.svg                       
rm network.svg

#start here 
rm distributor-logo.svg                   
rm novell-button.svg                 
rm gnome-main-menu.svg                                       

# saved search              
rm application-x-gnome-saved-search.svg   

              
# home 
rm gnome-fs-home.svg                      
rm folder_home.svg                        
                     
##

# network server 
#ln -s -f network-server.svg gnome-mime-x-directory-nfs-server.svg  
#ln -s -f network-server.svg gnome-mime-x-directory-smb-server.svg  
#ln -s -f network-server.svg gnome-mime-x-directory-smb-share.svg
#ln -s -f network-server.svg gnome-mime-x-directory-smb-workgroup.svg
#ln -s -f network-server.svg gnome-fs-server.svg                    
#ln -s -f network-server.svg redhat-network-server.svg
#ln -s -f network-server.svg server.svg

# net work group
#ln -s -f network-workgroup.svg gnome-fs-network.svg
#ln -s -f network-workgroup.svg gtk-network.svg            
#ln -s -f network-workgroup.svg network_local.svg


#user-bookmarks.svg

# trash 
#ln -s -f user-trash.svg trashcan_empty.svg
#ln -s -f user-trash.svg xfce-trash_empty.svg
#ln -s -f user-trash.svg emptytrash.svg                         
#ln -s -f user-trash.svg gnome-stock-trash.svg

# desktop
#ln -s -f user-desktop.svg desktop.svg                            
#ln -s -f user-desktop.svg gnome-fs-desktop.svg    
