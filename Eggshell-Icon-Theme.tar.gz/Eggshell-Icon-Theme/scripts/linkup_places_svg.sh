#!/bin/sh

# normal folder 
ln -s -f folder.svg gnome-fs-directory.svg
ln -s -f folder.svg gtk-directory.svg
ln -s -f folder.svg stock_folder.svg
ln -s -f folder.svg inode-directory.svg

# network folder
ln -s -f folder-remote.svg gnome-fs-share.svg                     
ln -s -f folder-remote.svg gnome-fs-smb.svg                      
ln -s -f folder-remote.svg gnome-fs-ssh.svg                     
ln -s -f folder-remote.svg gnome-fs-ftp.svg                       
ln -s -f folder-remote.svg gnome-fs-nfs.svg                       
ln -s -f folder-remote.svg network.svg

#start here 
ln -s -f start-here.svg distributor-logo.svg                   
ln -s -f start-here.svg novell-button.svg                 
ln -s -f start-here.svg gnome-main-menu.svg                                       
ln -s -f start-here.svg distributor-logo.svg      

# saved search              
ln -s -f folder-saved-search.svg application-x-gnome-saved-search.svg   

               

# home 
ln -s -f user-home.svg gnome-fs-home.svg                      
ln -s -f user-home.svg gnome-fs-home.svg 
ln -s -f user-home.svg folder_home.svg                        
                     
##

# network server 
#ln -s -f network-server.svg gnome-mime-x-directory-nfs-server.svg  
#ln -s -f network-server.svg gnome-mime-x-directory-smb-server.svg  
#ln -s -f network-server.svg gnome-mime-x-directory-smb-share.svg
#ln -s -f network-server.svg gnome-mime-x-directory-smb-workgroup.svg
#ln -s -f network-server.svg gnome-fs-server.svg                    
#ln -s -f network-server.svg redhat-network-server.svg
#ln -s -f network-server.svg server.svg

# net work group
#ln -s -f network-workgroup.svg gnome-fs-network.svg
#ln -s -f network-workgroup.svg gtk-network.svg            
#ln -s -f network-workgroup.svg network_local.svg


#user-bookmarks.svg

# trash 
#ln -s -f user-trash.svg trashcan_empty.svg
#ln -s -f user-trash.svg xfce-trash_empty.svg
#ln -s -f user-trash.svg emptytrash.svg                         
#ln -s -f user-trash.svg gnome-stock-trash.svg

# desktop
#ln -s -f user-desktop.svg desktop.svg                            
#ln -s -f user-desktop.svg gnome-fs-desktop.svg    
