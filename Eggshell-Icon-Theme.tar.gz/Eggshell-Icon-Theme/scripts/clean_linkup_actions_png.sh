
#back
rm back.png
rm gtk-go-back-ltr.png
rm gtk-go-forward-ltr.png
rm previous.png
rm stock_left.png

#next
rm forward.png    
rm gtk-go-back-rtr.png
rm gtk-go-forward-rtl.png
rm next.png
rm stock_right.png

#bottom
rm  bottom.png
rm  gtk-goto-bottom.png
rm  stock_bottom.png
#top
rm gtk-goto-top.png
rm stock_top.png
rm top.png

#up
rm gtk-go-up.png
rm stock_up.png
rm up.png

#down
rm down.png
rm gtk-go-down.png
rm stock_down.png

#last 
rm finish.png
rm gtk-goto-first-rtl.png
rm gtk-goto-last-ltl.png
rm stock_last.png

#first
rm gtk-goto-first-ltr.png
rm gtk-goto-last-rtl.png
rm start.png
rm stock_first.png

#home 
rm gohome.png
rm gtk-home.png
rm redhat-home.png
rm kfm-home.png
rm stock_home.png

#stop
rm gtk-stop.png
rm stock_stop.png
rm stop.png
rm gtk-cancel.png

#refresh
rm stock_refresh.png
rm reload.png
rm reload3.png
rm reload_all_tabs.png
rm reload_page.png
rm gtk-refresh.png
