
#back
ln -s -f go-previous.png  back.png
ln -s -f go-previous.png  gtk-go-back-ltr.png

ln -s -f go-previous.png previous.png
ln -s -f go-previous.png stock_left.png

#next
ln -s -f go-next.png forward.png    
ln -s -f go-next.png gtk-go-back-rtr.png
ln -s -f go-next.png gtk-go-forward-rtl.png
ln -s -f go-next.png next.png
ln -s -f go-next.png stock_right.png
ln -s -f go-next.png gtk-go-forward-ltr.png

#bottom
ln -s -f go-bottom.png  bottom.png
ln -s -f go-bottom.png  gtk-goto-bottom.png
ln -s -f go-bottom.png  stock_bottom.png
#top
ln -s -f go-top.png gtk-goto-top.png
ln -s -f go-top.png stock_top.png
ln -s -f go-top.png top.png

#up
ln -s -f go-up.png gtk-go-up.png
ln -s -f go-up.png stock_up.png
ln -s -f go-up.png up.png

#down
ln -s -f go-down.png down.png
ln -s -f go-down.png gtk-go-down.png
ln -s -f go-down.png stock_down.png

#last 
ln -s -f go-last.png finish.png
ln -s -f go-last.png gtk-goto-first-rtl.png
ln -s -f go-last.png gtk-goto-last-ltl.png
ln -s -f go-last.png stock_last.png

#first
ln -s -f go-first.png gtk-goto-first-ltr.png
ln -s -f go-first.png gtk-goto-last-rtl.png
ln -s -f go-first.png start.png
ln -s -f go-first.png stock_first.png

#home 
ln -s -f go-home.png gohome.png
ln -s -f go-home.png gtk-home.png
ln -s -f go-home.png redhat-home.png
ln -s -f go-home.png kfm-home.png
ln -s -f go-home.png stock_home.png

#stop
ln -s -f process-stop.png gtk-stop.png
ln -s -f process-stop.png stock_stop.png
ln -s -f process-stop.png stop.png
ln -s -f process-stop.png gtk-cancel.png

#refresh
ln -s -f view-refresh.png stock_refresh.png
ln -s -f view-refresh.png reload.png
ln -s -f view-refresh.png reload3.png
ln -s -f view-refresh.png reload_all_tabs.png
ln -s -f view-refresh.png reload_page.png
ln -s -f view-refresh.png stock_refresh.png
ln -s -f view-refresh.png gtk-refresh.png
