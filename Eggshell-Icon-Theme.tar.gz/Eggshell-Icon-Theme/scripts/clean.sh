#!/bin/sh

cd ../16x16/places
../../scripts/clean_linkup_places_png.sh

cd ../../22x22/places
../../scripts/clean_linkup_places_png.sh

cd ../../24x24/places
../../scripts/clean_linkup_places_png.sh

cd ../../scalable/places
../../scripts/clean_linkup_places_svg.sh

cd ../../16x16/actions
../../scripts/clean_linkup_actions_png.sh

cd ../../22x22/actions
../../scripts/clean_linkup_actions_png.sh

cd ../../24x24/actions
../../scripts/clean_linkup_actions_png.sh
