#!/bin/sh

mkdir -p ~/.icons/Eggshell

cd scripts

./install.sh	

echo "Linking stuff up"
cd ..


cp -r -b * ~/.icons/Eggshell

rm -R  ~/.icons/Eggshell/scripts
rm -R  ~/.icons/Eggshell/install-me.sh

echo "copying to ~/.icons"
echo "DONE!"
