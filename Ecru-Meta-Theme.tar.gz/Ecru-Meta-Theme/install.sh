#!/bin/sh

mkdir -p ~/.themes/Ecru
cp -r -b * ~/.themes/Ecru
mkdir -p ~/.bbtools
rm ~/.bbtools/bbpager.rc
ln ~/.themes/Ecru/bbpager.rc ~/.bbtools/bbpager.rc
rm ~/.themes/Ecru/install.sh
echo "copying to ~/.themes"
echo "DONE!"
